 

export class Partner
{
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;
partnerName:string;
address1:string;
address2:string;
city:string;
zipCode:string;
partnerTypeId:number;
email1:string;
email2:string;
phone1:string;
phone2:string;
contact1:string;
contact2:string;

}
