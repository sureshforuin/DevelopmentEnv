export class Package
{
public packageName:string;
public description:string;
public id:number;
public isActive:boolean;
public createdBy:string;
public updatedBy:string;
public createdAt:Date;
public updatedAt:Date;

}
