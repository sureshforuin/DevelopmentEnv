import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
 
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { ApiClientService } from '../services/api-client.service';
import {User} from '../models/user';
import { map } from 'rxjs/operators';
 
 import * as jwt_decode from 'jwt-decode';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loggedIn = false;
  currentUser: User;
  loggedInSubj = new Subject<boolean>();
  userSubj = new Subject<User>();



  expirationTimer: any;
  isAdmin=false;
  
  constructor(private http: ApiClientService, private router: Router,private route: ActivatedRoute) { 

    this.loggedIn = localStorage.getItem('token')? true:false;
  }

 
  
  isAuthenticated(){
    const promise = new Promise((resolve, reject) => {
      resolve(!!localStorage.getItem('token'));
    });
    return promise;
  }

  signUp(user: User){
    
    return this.http.postMethod<any>(user,'Authenticate' );
  }

  login(userName: string, password: string){
     
    return this.http.postMethod<any>({ userName, password }, 'Authenticate');
  }

  // autoLogin(){
  //   const userData: {name: string, email: string, expiresIn: string, roleId: number} = JSON.parse(localStorage.getItem('userData'));
  //   if (!userData){
  //     return;
  //   }

  //   const loadedUser = new User(userData.name, userData.email, userData.roleId, null, null, null, null, new Date(+userData.expiresIn));
  //   if (loadedUser.isLogged){
  //     this.loggedIn = true;
  //     this.loggedInSubj.next(true);
  //     this.userSubj.next(loadedUser);
  //     const expirationDuration =
  //     new Date(userData.expiresIn).getTime() - new Date().getTime();
  //     this.autoLogout(expirationDuration);    }
  // }

  logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('userData');
    this.loggedInSubj.next(false);
    this.userSubj.next(null);
    if (this.expirationTimer){
      clearTimeout(this.expirationTimer);
    }
    this.expirationTimer = null;
    this.router.navigate(['./login'])
    .then(() => {
      window.location.reload();
    })


  
  }

  autoLogout(expiresIn: number){
    this.expirationTimer =  setTimeout(() => {
      this.logout();
    }, expiresIn);
  }

  getToken(){
    return localStorage.getItem('token');
  }

  getUsers(){
     
    return this.http.get('Users');
  }
 
    
}
