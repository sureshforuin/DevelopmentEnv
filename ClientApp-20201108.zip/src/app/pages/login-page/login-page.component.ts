import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';  

import {LoginService} from '../../services/login.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  loading = false;
  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  errorMessage:string;
  public redirectUrl: string;
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
     
    private authService: LoginService) { }


    ngOnInit() {
      this.loginForm = this.formBuilder.group({
       

        userName: new FormControl('', [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$'),
        ]),
        password: new FormControl('', [Validators.required])
      });
    }

    get loginFormControl() { return this.loginForm.controls; }  
    login() {
    
      console.log(this.route.snapshot);
      const val = this.loginForm.value;
  
      this.submitted = true;
      if (this.loginForm.invalid) {
        return;
      }
      this.loading = true; 
        if (val.userName && val.password) {       
           
            this.authService.login(val.userName, val.password).subscribe(data => {

              console.log(data);
              localStorage.setItem('token', data.token);
              this.authService.loggedIn = true;
              this.authService.loggedInSubj.next(true);
        
              this.authService.currentUser = data.user;
              console.log(this.authService.currentUser);
          
              this.authService.userSubj.next(this.authService.currentUser);
        
              const expirationDuration =
                new Date(data.expires).getTime() - new Date().getTime();
              // this.authService.autoLogout(expirationDuration);
        

              this.router.navigate(['/']);
        
            },
            error => {
              if (error.error){
                this.errorMessage = error.error;
              }else{
                console.log(error);
                this.errorMessage = 'An unknown error occured';
              }
             
              this.loading = false;
            });
          }
        
  
  
          
          
    }
  }

  
  
   
  

 
