import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css']
})
export class WelcomePageComponent implements OnInit {
  userData:any;
  constructor( private router:Router) {

    if ( this.router.getCurrentNavigation().extras.state!=null)
    {
      var allData = this.router.getCurrentNavigation().extras.state.example;
    
        this.userData = allData.userData;
        
      console.log(allData);
    }
   }

  ngOnInit(): void {
  }

}
