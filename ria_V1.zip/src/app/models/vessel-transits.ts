export class VesselTransits
{
transitTerminal:string;
expArrival:Date;
expDeparture:Date;
isLoadingAvailable:boolean;
isDeliveryAvailable:boolean;
transitRouteNo:string;
scheduleId:number;
transitPortId:number;
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;

}
