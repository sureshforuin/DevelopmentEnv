import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
declare var $:any;
@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent implements OnInit {

  constructor(public service:LoginService, ) { }

  ngOnInit(): void {
  
 

    // Dropdown Menu Fade    
$(document).ready(function(){
  $(".dropdown").hover(
      function() { $('.dropdown-menu', this).fadeIn("fast");
      },
      function() { $('.dropdown-menu', this).fadeOut("fast");
  });
});
  }

  closeme() {
    $('.navbar-toggler:visible').click();
  }
  logOut(){}


}
