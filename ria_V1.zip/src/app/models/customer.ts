export class Customer
{
name:string;
address1:string;
address2:string;
city:string;
zipCode:string;
email:string;
phone:string;
country:string;
iecCode:string;
panNo:string;
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;

}
