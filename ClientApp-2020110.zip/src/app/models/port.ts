export class Port
{
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;
portCode:string;
cityCode:string;
countryCode:string;
cityDescription:string;
portDescription:string;
longDescription:string;
countryDescription:string;

}


 