import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray,Validators} from '@angular/forms';
import { Data, ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { Subscription,Subject, Observable} from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ModelMapper } from '../../utils/model-mapper';
import { Port } from 'src/app/models/port';
import { ApiClientService } from 'src/app/services/api-client.service';
 
import { VesselHeader} from '../../models/vessel-header';
import { StoreService } from 'src/app/utils/store-service';
@Component({
  selector: 'app-vessel-main',
  templateUrl: './vessel-main.component.html',
  styleUrls: ['./vessel-main.component.css']
})
export class VesselMainComponent implements OnInit {
  editVesselScheduleForm: FormGroup;
  schForm: FormGroup;
  vslSchedule: VesselHeader;
  transitPorts: any;
  originPorts:any;
  destPorts:any;
 submitted = false;
orderItems:any;
  ports: Port[];
  portsSub:Subscription;
cities :any[];
orginCities:any[];
destCities:any[];
newDynamic: any = {};
entities: any[];
hideBE: true;
controls: FormArray;
selected: string[]=[];
sub: any;
constructor(private apiClient : ApiClientService, private utils:StoreService,
    private frmBldr: FormBuilder,  private route: ActivatedRoute,private router: Router) {

      if (this.router.getCurrentNavigation().extras.state!= null)
      {
        
        this.vslSchedule = new ModelMapper(VesselHeader).map(this.router.getCurrentNavigation().extras.state); 
        
      }
 
      this.portsSub=this.utils.activePorts$.subscribe(data =>
        this.ports= data
        );
      
   
        this.portsSub=this.utils.activePorts$.subscribe(data =>
          this.originPorts= data
          );
        
       
          this.portsSub=this.utils.activePorts$.subscribe(data =>
            this.destPorts= data
            );
          
            this.portsSub=this.utils.activePorts$.subscribe(data =>
              this.transitPorts= data
              );
              this.portsSub=this.utils.activePorts$.subscribe(data =>
                this.cities =  data.map(obj => ({ value: obj.cityCode, label: obj.cityDescription }))
               
                );
                this.portsSub=this.utils.activePorts$.subscribe(data =>
                  this.orginCities =  data.map(obj => ({ value: obj.cityCode, label: obj.cityDescription }))
                 
                  );

                  this.portsSub=this.utils.activePorts$.subscribe(data =>
                    this.destCities =  data.map(obj => ({ value: obj.cityCode, label: obj.cityDescription }))
                   
                    );
               
     
      
     

       if (this.vslSchedule != null)
       {
        this.editVesselScheduleForm = this.frmBldr.group({
      
          id: this.vslSchedule.id,
          isActive: this.vslSchedule.isActive,
          createdBy: this.vslSchedule.createdBy,
          updatedBy: this.vslSchedule.updatedBy,
          createdAt: this.vslSchedule.createdAt,
          updatedAt: this.vslSchedule.updatedAt,
          vesselName: [this.vslSchedule.vesselName,  Validators.required,],
          voyageNo: [this.vslSchedule.voyageNo, Validators.required,],
          originCity: [this.vslSchedule.originPort.cityCode, Validators.required],
          destinationCity: [this.vslSchedule.destinationPort.cityCode, Validators.required],
          originTerminal: this.vslSchedule.originTerminal,
          estArrOriDate:this.formatDate(this.vslSchedule.estArrOriDate),
          estBerthDate:this.formatDate(this.vslSchedule.estBerthDate),
          estGateOpenDate:this.formatDate(this.vslSchedule.estGateOpenDate),
          estCutOffDate: this.formatDate(this.vslSchedule.estCutOffDate),
          estDepDate: [this.formatDate(this.vslSchedule.estDepDate), Validators.required,],
          destinationTerminal: this.vslSchedule.destinationTerminal,
          estArrDestDate: [this.formatDate(this.vslSchedule.estArrDestDate), Validators.required,],
          originPortId: [this.vslSchedule.originPortId, Validators.required],
          destinationPortId: [this.vslSchedule.destinationPortId, Validators.required,],
           });

           this.entities = this.vslSchedule.details;
           this.processData();

       }
       else

       {
      this.editVesselScheduleForm = this.frmBldr.group({
      
        id: 0,
        isActive: true,
        createdBy: [''],
        updatedBy: [''],
        createdAt: [''],
        updatedAt: [''],
        vesselName: ['',  Validators.required,],
        voyageNo: ['', Validators.required,],
        originCity: ['', Validators.required],
        destinationCity: ['', Validators.required],
        originTerminal: [''],
        estArrOriDate: [''],
        estBerthDate: [''],
        estGateOpenDate: [''],
        estCutOffDate: [''],
        estDepDate: ['', Validators.required,],
        destinationTerminal: [''],
        estArrDestDate: ['', Validators.required,],
        originPortId: ['', Validators.required],
        destinationPortId: ['', Validators.required,],
         });
        }
 
}
getControl(index: number, field: string): FormControl {
  return this.controls.at(index).get(field) as FormControl;
}

formatDate(dtValue: Date)
{
  return new Date(dtValue).toISOString().slice(0,10);
}
   
processData() {
  const toGroups = this.entities.map(entity => {

    return new FormGroup({
      id: new FormControl(entity.id, Validators.required),
      scheduleId: new FormControl(entity.scheduleId, Validators.required),
      
      transitPort: new FormControl(entity.transitPort, Validators.required),
      transitPortId: new FormControl(entity.transitPortId, Validators.required),
      transitTerminal: new FormControl(entity.transitTerminal, Validators.required),
      expArrival: new FormControl(entity.expArrival, Validators.required),
      expDeparture: new FormControl(entity.expDeparture, Validators.required),
      isLoadingAvailable: new FormControl(entity.isLoadingAvailable, Validators.required),
      isDeliveryAvailable: new FormControl(entity.isDeliveryAvailable, Validators.required),
      transitRouteNo: new FormControl(entity.transitRouteNo, Validators.required),

      createdBy: new FormControl(entity.createdBy),
      updatedBy: new FormControl(entity.updatedBy),
      createdAt: new FormControl(entity.createdAt),
      updatedAt: new FormControl(entity.updatedAt),
    });
  });
  this.controls = new FormArray(toGroups);
}
deleteRow(e, index) {
  this.entities.splice(index, 1);

  //if (e.VesselSchedules > 0) {
  //  this.apiClient.Delete<any>('VesselSchedules', e.superCategoryId).toPromise().then((data) => {
  //     this.FillData();
  //   }).catch((error) => {
  //     console.log("Promise rejected with " + JSON.stringify(error));

  //   });
  // }
  // else { this.entities.splice(index, 1);}
}
addRow() {


var scheduleId= 0;

if (this.entities!=null && this.entities.length>0)
{
  scheduleId= this.entities.find((item) => item.scheduleId>0)==undefined?0 : this.entities.find((item) => item.scheduleId>0).scheduleId ;
 // console.log('ccccccc' + scheduleId)
}
  this.newDynamic = {
    id: 0,
    scheduleId:scheduleId,
    transitPort: {
      id: -1, portCode: 'portcode',
      longDescription: 'longDescription'
    },
    transitPortId:-1,
    transitTerminal: 'transitTerminal',
    expArrival: 'expArrival',
    expDeparture: 'expDeparture',
    isLoadingAvailable: false,
    isDeliveryAvailable: false,
    transitRouteNo: 'transitRouteNo',
    createdBy: null, updatedBy: null, createdAt: null, updatedAt: null
  };
  if (this.entities != null && this.entities.length > 0) {
    this.entities.splice(0, 0, this.newDynamic);
  }
  else {
    this.entities = [];
    this.entities.push(this.newDynamic);
  }

  this.processData();
  return true;
}
updateField(index: number, field: string) {

  const control = this.getControl(index, field);

  if (control.valid) {

    this.processData();
    this.entities = this.entities.map((e, i) => {
      if (index === i) {
        return {
          ...e,
          [field]: control.value
        }
      }
      return e;
    })
  }

}
  onSubmit() {
 
//controls. get('vesselName').
if (this.entities!=null)
{
  this.processData();


}

 

let x  ={
id:this.editVesselScheduleForm.value.id,
 
isActive: this.editVesselScheduleForm.value.isActive,
createdBy: this.editVesselScheduleForm.value.createdBy,
updatedBy: this.editVesselScheduleForm.value.updatedBy,
createdAt: this.editVesselScheduleForm.value.createdAt,
updatedAt: this.editVesselScheduleForm.value.updatedAt,
vesselName:this.editVesselScheduleForm.value.vesselName,
voyageNo:this.editVesselScheduleForm.value.voyageNo,
originTerminal:this.editVesselScheduleForm.value.originTerminal,
estArrOriDate:this.editVesselScheduleForm.value.estArrOriDate,
estBerthDate:this.editVesselScheduleForm.value.estBerthDate,
estGateOpenDate:this.editVesselScheduleForm.value.estGateOpenDate,
estCutOffDate:this.editVesselScheduleForm.value.estCutOffDate,
estDepDate:this.editVesselScheduleForm.value.estDepDate,
destinationTerminal:this.editVesselScheduleForm.value.destinationTerminal,
estArrDestDate:this.editVesselScheduleForm.value.estArrDestDate,
originPortId:parseInt(this.editVesselScheduleForm.value.originPortId),
destinationPortId:parseInt(this.editVesselScheduleForm.value.destinationPortId),
details :this.entities,
}
console.log(x);
 this.apiClient.postMethod(x,'VesselSchedules').toPromise().then((data => {console.log(data);})).catch((err=> {console.log(err);}))
   // this.vslSchedule.vesselName : this.editVesselScheduleForm.value['vesselName'];
   
  }

  onPortChange()
  {
    this.selected.length =0;

    if (this.editVesselScheduleForm.getRawValue()['originPortId']>0)
    {

      this.selected.push(this.editVesselScheduleForm.getRawValue()['originPortId'])

    }
    
   if (this.editVesselScheduleForm.getRawValue()['destinationPortId']>0)
    {

      this.selected.push(this.editVesselScheduleForm.getRawValue()['destinationPortId'])
      
    }
    
 

    this.transitPorts = this.ports.filter((port) =>!this.selected.includes(port.id.toString()) );

 

   console.log(this.transitPorts);
  }
 onCityChange(event: Event) {

  const selCity = (event.target as HTMLSelectElement).value;
  const portControl = (event.target as HTMLSelectElement).getAttribute(
    'FormControlName'
  );

  switch (portControl) {
    case 'originCity': {
      this.originPorts = this.ports.filter(
        (item) => item.cityCode === selCity
      );

      this.destCities = this.cities.filter((item)=> item.value!==selCity);
   
      break;
    }
    case 'destinationCity': {
      this.destPorts = this.ports.filter(
        (item) => item.cityCode === selCity
      );

      this.orginCities = this.cities.filter((item)=> item.value!==selCity);
      break;
    }
  
 }
}
  getTransitControls() {
    return (this.schForm.get('vessel_transits') as FormArray).controls;
  }

 goBack() {
    this.router.navigate(['/schedules']);
  }
    
ngOnInit() {
  
  
 

 
}





onVesselInfoSubmit(){
  this.submitted = true;
console.log(this.editVesselScheduleForm.getRawValue());
        // stop here if form is invalid
     
}


  
}
