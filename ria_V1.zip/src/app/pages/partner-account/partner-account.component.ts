import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner-account',
  templateUrl: './partner-account.component.html',
  styleUrls: ['./partner-account.component.css']
})
export class PartnerAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
